
<!--- Start Footer -->
	<footer>
		<div class="container">
			<div class="row text-center py-5">
				<div class="col-md-4">
					<img src="img/Rr.png">
					
				</div>
				<div class="col-md-4">
					<h3 class="text-center">CONTACT INFO</h3><strong>Contact Info</strong>
					<p>+8801869831718<br>
					ragib.aseb@gmail.com</p>
				</div>
				<div class="col-md-4 pb-5">
				<h3 class="text-center">CONNECT WITH ME</h3><br>	
				<a href="https://www.facebook.com/profile.php?id=100010010146687" target="_blank"><i class="fab fa-facebook-square">facebook</i> </a>
				<a href="https://twitter.com/AsebRagib" target="_blank"><i class="fab fa-twitter-square">twitter</i></a>
				<a href="https://www.instagram.com/ragib.aseb/?hl=en" target="_blank"><i class="fab fa-instagram">instagram</i></a>

				</div>
			</div><!--- End of Row -->
		</div><!--- End of Container -->
	</footer>
	<!--- End of Footer -->